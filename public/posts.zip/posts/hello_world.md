+++
categories = ["CodingByDay"]
date = "2022-09-02"
description = "Just a hello"
featured = "pic01.jpg"
featuredalt = ""
featuredpath = "date"
linktitle = ""
title = "Hello world"
slug = "Hello"
type = "post"
+++

## Introduction

Hello world